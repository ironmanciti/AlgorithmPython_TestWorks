from setuptools import setup

setup(
    name='module_test',
    version="1.0.0",
    description="test packaging", 
    author="YJOh",
    author_email="test@gmail.com",
    url="www.test.com",
    py_modules=['module_test']
)