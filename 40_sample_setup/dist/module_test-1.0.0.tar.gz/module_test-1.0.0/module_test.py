def circle(pi, radius):
    print("pi = ", pi)
    print("반지름 = ", radius)
    return pi * radius ** 2

def calculate_volume(length, width, depth):
    return length * width * depth

